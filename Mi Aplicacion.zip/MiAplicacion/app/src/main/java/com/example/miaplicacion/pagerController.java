package com.example.miaplicacion;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class pagerController extends FragmentPagerAdapter {

    int numoftabs;

    public pagerController(FragmentManager supportFragmentManager, int tabCount) {
        super(supportFragmentManager, tabCount);
    }

    public void PagerController(@NonNull FragmentManager fm, int behavior){
        super(fm, behavior);
        this.numoftabs = behavior;
    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
       switch (position){
           case 0:
               return new facebook();
           case 1:
               return new whatsapp();
           case 2:
               return new instagram();
               default:
                   return null;
       }
    }

    @Override
    public int getCount() {
        return numoftabs;
    }
}
